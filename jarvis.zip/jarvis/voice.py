"""Offline voice input/output using pyttsx3 and PocketSphinx (no cloud APIs)."""

from __future__ import annotations

import threading

import pyttsx3
import speech_recognition as sr


class VoiceEngine:
    """Text-to-speech and optional offline speech-to-text."""

    def __init__(self, rate: int = 175, volume: float = 1.0) -> None:
        self._engine = pyttsx3.init()
        self._engine.setProperty("rate", rate)
        self._engine.setProperty("volume", volume)
        self._recognizer = sr.Recognizer()
        self._mic: sr.Microphone | None = None
        self._lock = threading.Lock()

    @property
    def microphone_available(self) -> bool:
        try:
            self._mic = sr.Microphone()
            return True
        except (OSError, AttributeError):
            self._mic = None
            return False

    def speak(self, text: str) -> None:
        """Speak text aloud (blocks until finished)."""
        with self._lock:
            self._engine.say(text)
            self._engine.runAndWait()

    def listen(self, timeout: float = 5.0, phrase_limit: float = 10.0) -> str | None:
        """
        Listen via microphone and transcribe offline with PocketSphinx.
        Returns None if recognition fails or microphone is unavailable.
        """
        if self._mic is None and not self.microphone_available:
            return None

        assert self._mic is not None

        with self._mic as source:
            self._recognizer.adjust_for_ambient_noise(source, duration=0.4)
            try:
                audio = self._recognizer.listen(
                    source, timeout=timeout, phrase_time_limit=phrase_limit
                )
            except sr.WaitTimeoutError:
                return None

        try:
            return self._recognizer.recognize_sphinx(audio)
        except sr.UnknownValueError:
            return None
        except sr.RequestError:
            return None

    def shutdown(self) -> None:
        with self._lock:
            try:
                self._engine.stop()
            except RuntimeError:
                pass
