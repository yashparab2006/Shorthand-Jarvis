"""Offline response engine — pattern matching, tools, and conversation memory."""

from __future__ import annotations

import ast
import datetime as dt
import operator as op
import random
import re
from dataclasses import dataclass, field


_SAFE_OPS = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.FloorDiv: op.floordiv,
    ast.Mod: op.mod,
    ast.Pow: op.pow,
    ast.USub: op.neg,
    ast.UAdd: op.pos,
}

_JOKES = [
    "Why do programmers prefer dark mode? Because light attracts bugs.",
    "I told my computer I needed a break. It said: no problem, I'll go to sleep.",
    "There are only 10 types of people: those who understand binary and those who don't.",
    "Why did the developer go broke? Because he used up all his cache.",
]

_QUOTES = [
    "The best way to predict the future is to invent it.",
    "Simplicity is the soul of efficiency.",
    "Code is like humor. When you have to explain it, it's bad.",
]

_FALLBACKS = [
    "I'm not sure about that. Try asking for help to see what I can do offline.",
    "Interesting question. I work fully offline, so my knowledge is limited to built-in commands.",
    "I don't have an answer for that yet. You can ask me about time, math, notes, or jokes.",
]


@dataclass
class JarvisBrain:
    user_name: str = "User"
    messages: list[dict[str, str]] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    reminders: list[str] = field(default_factory=list)

    def respond(self, message: str) -> str:
        text = message.strip()
        if not text:
            return "I didn't catch that. Please say or type something."

        self.messages.append({"role": "user", "content": text})
        reply = self._route(text)
        self.messages.append({"role": "assistant", "content": reply})
        return reply

    def clear_history(self) -> str:
        self.messages.clear()
        return "Conversation history cleared."

    def _route(self, text: str) -> str:
        lower = text.lower()

        if lower in {"exit", "quit", "bye", "goodbye"}:
            return f"Goodbye{', ' + self.user_name if self.user_name != 'User' else ''}! Shutting down."

        if re.search(r"\bhelp\b|\bwhat can you do\b", lower):
            return self._help_text()

        if m := re.search(r"(?:my name is|call me|i am|i'm)\s+([a-zA-Z][a-zA-Z\s'-]{0,30})", lower):
            self.user_name = m.group(1).strip().title()
            return f"Nice to meet you, {self.user_name}. I'll remember your name."

        if re.search(r"what(?:'s| is) my name", lower):
            return f"Your name is {self.user_name}."

        if re.search(r"\btime\b|\bwhat time\b", lower):
            now = dt.datetime.now().strftime("%I:%M %p")
            return f"The current time is {now}."

        if re.search(r"\bdate\b|\btoday\b|\bwhat day\b", lower):
            today = dt.datetime.now().strftime("%A, %B %d, %Y")
            return f"Today is {today}."

        if re.search(r"\bjoke\b|\bfunny\b", lower):
            return random.choice(_JOKES)

        if re.search(r"\bquote\b|\bmotivat", lower):
            return random.choice(_QUOTES)

        if re.search(r"\bflip (?:a )?coin\b", lower):
            return random.choice(["Heads!", "Tails!"])

        if m := re.search(r"\broll (?:a )?(?:d)?(\d+)\b", lower):
            sides = max(2, min(int(m.group(1)), 1000))
            return f"You rolled a {random.randint(1, sides)} on a D{sides}."

        if re.search(r"\bclear history\b|\breset chat\b", lower):
            self.messages.clear()
            return "Conversation history cleared."

        if m := re.search(r"(?:remember|note|save)\s+(?:that\s+)?(.+)", lower):
            note = m.group(1).strip()
            if note:
                self.notes.append(note)
                return f"Noted: {note}"

        if re.search(r"\b(show|list|read) notes\b|\bmy notes\b", lower):
            if not self.notes:
                return "You have no saved notes yet."
            lines = "\n".join(f"{i + 1}. {n}" for i, n in enumerate(self.notes))
            return f"Your notes:\n{lines}"

        if m := re.search(r"(?:remind me to|set reminder)\s+(.+)", lower):
            reminder = m.group(1).strip()
            if reminder:
                self.reminders.append(reminder)
                return f"Reminder set: {reminder}"

        if re.search(r"\b(show|list) reminders\b", lower):
            if not self.reminders:
                return "You have no reminders."
            lines = "\n".join(f"{i + 1}. {r}" for i, r in enumerate(self.reminders))
            return f"Your reminders:\n{lines}"

        if m := re.search(
            r"(?:calculate|compute|what is|what's)\s+([\d\s+\-*/().^%]+)",
            lower,
        ):
            result = self._safe_calc(m.group(1))
            if result is not None:
                return f"The answer is {result}."

        if self._looks_like_math(text):
            result = self._safe_calc(text)
            if result is not None:
                return f"The answer is {result}."

        if m := re.search(r"convert\s+([\d.]+)\s+(\w+)\s+to\s+(\w+)", lower):
            converted = self._convert(float(m.group(1)), m.group(2), m.group(3))
            if converted is not None:
                return converted

        if re.search(r"\bhello\b|\bhi\b|\bhey\b", lower):
            return f"Hello{', ' + self.user_name if self.user_name != 'User' else ''}! How can I help you today?"

        if re.search(r"\bhow are you\b", lower):
            return "I'm running smoothly offline. Ready for your next command."

        if re.search(r"\bthank", lower):
            return "You're welcome!"

        if len(self.messages) >= 2:
            last_user = next(
                (m["content"] for m in reversed(self.messages[:-1]) if m["role"] == "user"),
                None,
            )
            if last_user and last_user.lower() == lower:
                return "You just asked that. Would you like me to explain differently?"

        return random.choice(_FALLBACKS)

    @staticmethod
    def _help_text() -> str:
        return (
            "I'm Jarvis — fully offline, no API keys needed.\n"
            "Try: time, date, jokes, quotes, flip coin, roll dice,\n"
            "calculate 15 * 7, remember <note>, show notes, remind me to <task>,\n"
            "convert 10 km to miles, my name is <name>, clear history, or exit.\n"
            "Enable voice mode to speak and listen (offline PocketSphinx)."
        )

    @staticmethod
    def _looks_like_math(text: str) -> bool:
        cleaned = re.sub(r"\s+", "", text)
        return bool(re.fullmatch(r"[\d+\-*/().^%]+", cleaned))

    @staticmethod
    def _safe_calc(expr: str) -> float | int | None:
        expr = expr.replace("^", "**").replace("%", "/100*")
        expr = re.sub(r"[^\d+\-*/().\s]", "", expr)
        try:
            node = ast.parse(expr, mode="eval")
            return JarvisBrain._eval_node(node.body)
        except (SyntaxError, TypeError, ValueError, ZeroDivisionError, OverflowError):
            return None

    @staticmethod
    def _eval_node(node: ast.AST) -> float | int:
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp):
            left = JarvisBrain._eval_node(node.left)
            right = JarvisBrain._eval_node(node.right)
            fn = _SAFE_OPS.get(type(node.op))
            if fn is None:
                raise ValueError("unsupported operator")
            return fn(left, right)
        if isinstance(node, ast.UnaryOp):
            fn = _SAFE_OPS.get(type(node.op))
            if fn is None:
                raise ValueError("unsupported unary operator")
            return fn(JarvisBrain._eval_node(node.operand))
        raise ValueError("unsupported expression")

    @staticmethod
    def _convert(value: float, from_unit: str, to_unit: str) -> str | None:
        conversions: dict[tuple[str, str], float] = {
            ("km", "miles"): 0.621371,
            ("miles", "km"): 1.60934,
            ("kg", "lbs"): 2.20462,
            ("lbs", "kg"): 0.453592,
        }
        key = (from_unit.rstrip("s"), to_unit.rstrip("s"))
        if key == ("c", "f"):
            result = value * 9 / 5 + 32
            return f"{value}°C is {result:.2f}°F."
        if key == ("f", "c"):
            result = (value - 32) * 5 / 9
            return f"{value}°F is {result:.2f}°C."
        factor = conversions.get(key)
        if factor is None:
            return None
        result = value * factor
        return f"{value} {from_unit} is {result:.4g} {to_unit}."
